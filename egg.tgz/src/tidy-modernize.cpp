// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("tidy modernize\n", stdout);
  return lionss_run_workload("tidy-modernize");
}
