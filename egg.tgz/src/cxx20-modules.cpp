// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("cxx20 modules\n", stdout);
  return lionss_run_workload("cxx20-modules");
}
