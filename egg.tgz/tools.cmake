# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(cxx20-modules src/cxx20-modules.cpp)
set_property(TARGET cxx20-modules PROPERTY CXX_STANDARD 11)
target_link_libraries(cxx20-modules lionss pthread)

add_executable(encoding-tests src/encoding-tests.cpp)
set_property(TARGET encoding-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(encoding-tests lionss pthread)

add_executable(raspberry-pi src/raspberry-pi.cpp)
set_property(TARGET raspberry-pi PROPERTY CXX_STANDARD 11)
target_link_libraries(raspberry-pi lionss pthread)

add_executable(portable-binary src/portable-binary.cpp)
set_property(TARGET portable-binary PROPERTY CXX_STANDARD 11)
target_link_libraries(portable-binary lionss pthread)

add_executable(interop-tests src/interop-tests.cpp)
set_property(TARGET interop-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(interop-tests lionss pthread)

add_executable(rollback-tests src/rollback-tests.cpp)
set_property(TARGET rollback-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(rollback-tests lionss pthread)

add_executable(cmake-presets src/cmake-presets.cpp)
set_property(TARGET cmake-presets PROPERTY CXX_STANDARD 11)
target_link_libraries(cmake-presets lionss pthread)

add_executable(section-sizes src/section-sizes.cpp)
set_property(TARGET section-sizes PROPERTY CXX_STANDARD 11)
target_link_libraries(section-sizes lionss pthread)

add_executable(undefined-sanitizer src/undefined-sanitizer.cpp)
set_property(TARGET undefined-sanitizer PROPERTY CXX_STANDARD 11)
target_link_libraries(undefined-sanitizer lionss pthread)

add_executable(hot-path-profile src/hot-path-profile.cpp)
set_property(TARGET hot-path-profile PROPERTY CXX_STANDARD 11)
target_link_libraries(hot-path-profile lionss pthread)

add_executable(package-pkg src/package-pkg.cpp)
set_property(TARGET package-pkg PROPERTY CXX_STANDARD 11)
target_link_libraries(package-pkg lionss pthread)

add_executable(clang-18 src/clang-18.cpp)
set_property(TARGET clang-18 PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-18 lionss pthread)

add_executable(markdown-lint src/markdown-lint.cpp)
set_property(TARGET markdown-lint PROPERTY CXX_STANDARD 11)
target_link_libraries(markdown-lint lionss pthread)

add_executable(crash-handler-test src/crash-handler-test.cpp)
set_property(TARGET crash-handler-test PROPERTY CXX_STANDARD 11)
target_link_libraries(crash-handler-test lionss pthread)

add_executable(lock-bench src/lock-bench.cpp)
set_property(TARGET lock-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(lock-bench lionss pthread)

add_executable(compatibility-tests src/compatibility-tests.cpp)
set_property(TARGET compatibility-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(compatibility-tests lionss pthread)

add_executable(advisory-sync src/advisory-sync.cpp)
set_property(TARGET advisory-sync PROPERTY CXX_STANDARD 11)
target_link_libraries(advisory-sync lionss pthread)

add_executable(functional-tests src/functional-tests.cpp)
set_property(TARGET functional-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(functional-tests lionss pthread)

add_executable(cache-warmup src/cache-warmup.cpp)
set_property(TARGET cache-warmup PROPERTY CXX_STANDARD 11)
target_link_libraries(cache-warmup lionss pthread)

add_executable(gdb-pretty-print src/gdb-pretty-print.cpp)
set_property(TARGET gdb-pretty-print PROPERTY CXX_STANDARD 11)
target_link_libraries(gdb-pretty-print lionss pthread)

add_executable(doxygen src/doxygen.cpp)
set_property(TARGET doxygen PROPERTY CXX_STANDARD 11)
target_link_libraries(doxygen lionss pthread)

add_executable(tidy-modernize src/tidy-modernize.cpp)
set_property(TARGET tidy-modernize PROPERTY CXX_STANDARD 11)
target_link_libraries(tidy-modernize lionss pthread)

add_executable(lcov-report src/lcov-report.cpp)
set_property(TARGET lcov-report PROPERTY CXX_STANDARD 11)
target_link_libraries(lcov-report lionss pthread)

add_executable(vendored-check src/vendored-check.cpp)
set_property(TARGET vendored-check PROPERTY CXX_STANDARD 11)
target_link_libraries(vendored-check lionss pthread)

add_executable(build-pic src/build-pic.cpp)
set_property(TARGET build-pic PROPERTY CXX_STANDARD 11)
target_link_libraries(build-pic lionss pthread)

add_executable(heap-profile src/heap-profile.cpp)
set_property(TARGET heap-profile PROPERTY CXX_STANDARD 11)
target_link_libraries(heap-profile lionss pthread)

add_executable(clang-format src/clang-format.cpp)
set_property(TARGET clang-format PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-format lionss pthread)

add_executable(in-source-guard src/in-source-guard.cpp)
set_property(TARGET in-source-guard PROPERTY CXX_STANDARD 11)
target_link_libraries(in-source-guard lionss pthread)

add_executable(dead-code-scan src/dead-code-scan.cpp)
set_property(TARGET dead-code-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(dead-code-scan lionss pthread)

add_executable(infer-analyze src/infer-analyze.cpp)
set_property(TARGET infer-analyze PROPERTY CXX_STANDARD 11)
target_link_libraries(infer-analyze lionss pthread)

