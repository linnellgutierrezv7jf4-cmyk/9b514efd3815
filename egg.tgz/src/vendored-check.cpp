// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("vendored check"); }
int main(){
  announce();
  return lionss_run_workload("vendored-check");
}
